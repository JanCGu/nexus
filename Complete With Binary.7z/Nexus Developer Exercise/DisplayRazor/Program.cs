﻿namespace DisplayRazor {
    internal class Program {

        public static void Main(string[] args) {
            DisplayRazorServices.Start(args);//Starts the web application with the Razor Implementation.
        }
    }
}